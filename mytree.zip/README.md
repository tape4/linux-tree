# linux-tree  
## Homework 1 - Tree 명령어 구현
2019203032 이정훈  

```
make
# Move "mytree" file to the directory where you want to view the tree structure.
./mytree
```
